package com.example.firstandriod;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;


public class Sign_Up extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

    }
}